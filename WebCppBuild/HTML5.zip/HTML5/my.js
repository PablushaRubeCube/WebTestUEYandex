function ShowAdv() {
    if (ysdk && ysdk.adv){
    ysdk.adv.showFullscreenAdv({
        callbacks: {
            onClose: function(wasShown) {
                console.log('Ad was closed');
            },
            onError: function(error) {
                console.error('Error showing ad:', error);
            }
        }
    });
}
}